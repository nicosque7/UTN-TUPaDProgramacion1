precio_max=0
precio_des=0
ahorro=precio_max-precio_des
while True:
    nombre=input("Cual es el nombre del cliente: ").strip().capitalize()
    if nombre=="":
        print("Campo obligatorio, poner un nombre")
        continue
    elif not nombre.isalpha():
        print("Error. ingrese solo letras")
        continue
    else:
        nombre=str(nombre) 
        break
while True:
    productos=input("Cuantos productos desea comprar: ").strip()
    if productos=="":
        print("Campo obligatorio, ingrese la cantdidad")
        continue
    elif not productos.isdigit():
        print("Error, tiene que poner caracteres numericos")
        continue
    else:
        productos=int(productos)
        break
for i in range(productos):
    promedio=precio_des / productos
    descuento=False
    while True:
        cual_prod=input("Cual producto va a comprar: ").capitalize().strip()
        cual_precio=input("Cual es el precio del producto: ")
        if cual_precio=="" or cual_prod=="":
            print("Campo obligatorio")
            continue
        elif not cual_precio.isdigit():
            print("Error. ingrese solo numeros enteros")
            continue
        elif not cual_prod.isalpha():
            print("Error ingrese solo letras")
            continue
        else:
            cual_precio=int(cual_precio)
            precio_max+=cual_precio
        tiene_descuento=input("El producto tiene descuento (s/n): ").lower().strip()
        if tiene_descuento=="":
            print("Porfavor no deje vacio este campo")
            continue
        elif not tiene_descuento=="s" and not tiene_descuento=="n":
            print("Ingrese solo n o s")
            continue
        if tiene_descuento=="n":
            print("sin descuento")
            descuento=False
        elif tiene_descuento=="s":
            descuentito=cual_precio-(cual_precio*0.10)
            precio_des+=descuentito
            descuento=True
            break
print(f"""Nombre: {nombre}
        Cantidad de productos: {productos}
        {cual_prod}: {cual_precio} Descuento s/n: {"s" if descuento else "n"}
        Total sin descuento: {precio_max}
        Total con descuento: {precio_des}
        Ahorro: {ahorro}
        Promedio por producto: {promedio}
        """)